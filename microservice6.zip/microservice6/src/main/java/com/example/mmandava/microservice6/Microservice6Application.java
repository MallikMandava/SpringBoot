package com.example.mmandava.microservice6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservice6Application {

	public static void main(String[] args) {
		SpringApplication.run(Microservice6Application.class, args);
	}

}
